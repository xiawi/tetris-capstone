# General settings
SEED = None # Seven bag and garbage seed
PLAYER = False

# Controls (if PLAYER)
DAS = 80
ARR = 0
SDF = 0

# GA Stuff
MAX_PIECES = 1000000
MUTATION_RATE = 0.3