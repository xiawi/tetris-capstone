import pygame

from settings import SEED
from gamecontroller import GameController
from tetromino import Tetromino
from sevenbag import SevenBag
from botonly_renderer import Renderer
from bot import Bot
from garbagesystem import GarbageSystem

class GameManager():
  def __init__(self):
    if SEED:
      seed = SEED
    else:
      seed = 1

    self.bag = SevenBag(seed)
    self.garbage_system = GarbageSystem(seed)

    self.board = GameController(self.bag, self.garbage_system)
    self.bot = Bot(self.board, [-1, -1, -1, -1, -0.2806244752972613, -0.9981086798910379, 0.07718788025481071, 0.002715150494067675, -1, 1])
    self.renderer = Renderer(self.board)
    self.clock = pygame.time.Clock()

  def run(self) -> GameController:
    running = True
    while running:
      try:
        self.clock.tick(120)  # Keep smooth rendering
        self.renderer.render()  # Render the board
        self.bot.takeAction()

        if self.board.has_lost or self.board.tetrominos_placed > 1000:
          pygame.time.wait(1000)
          break

        for event in pygame.event.get():
          if event.type == pygame.QUIT:
            pygame.quit()
            exit()  # Exit the game
          # if event.type == pygame.KEYDOWN:
          #   self.bot.takeAction()
      except:
        running = False
    return self.board.total_attack
    

if __name__ == "__main__":
  pygame.init()
  gm = GameManager()
  print(gm.run())