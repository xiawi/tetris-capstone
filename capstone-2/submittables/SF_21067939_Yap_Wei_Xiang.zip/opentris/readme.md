# OpenTris
OpenTris is an open source tetris simulator built specifically to aid in research work.

